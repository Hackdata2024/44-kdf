import count from './count.wav'

export { count }